/// <reference types="cypress" />

const { contains } = require("cypress/types/jquery")


describe('workflow test', () =>{
    beforeEach(() => {
        cy.visit('/')
    })

    it('first test', () =>{

        cy.contains('登 入').click()
        cy.get('[name="username"]').should('contain','').clear().type('admin@RUBYS')
        cy.get('[name="password"]').should('contain','').clear().type('YvrK3ZQX')
        cy.get('[name="username"]').parents('form').contains('[type="submit"]','登入').click()
        cy.get('[i18nkey="workflow"]').click()
        cy.wait(3000)
        cy.contains('button','新增').click()
        cy.get('[placeholder="顧客旅程"]').should('contain','').clear().type('Test')
        cy.contains('button','完 成').click()
        cy.get('.ui:nth-child(1) > .list > .item:nth-child(1) > .content > i > svg > .workflow-node-main-box')
             .trigger('mousedown' )
             .trigger('mousemove',{ which: 1, cx: 50,cy:50})
             .trigger('mouseup')
    })
    it.only('first test', () =>{

        cy.contains('登 入').click()
        cy.get('[name="username"]').should('contain','').clear().type('admin@RUBYS')
        cy.get('[name="password"]').should('contain','').clear().type('YvrK3ZQX')
        cy.get('[name="username"]')
          .parents('form')
          .contains('[type="submit"]','登入')
          .click()
        cy.get('[i18nkey="workflow"]').click()
        cy.wait(3000)
        cy.get('.ant-btn ant-btn-default action-btn')
            // .parents('td').find('button').should('contain','編輯').click()
        cy.get('.ant-table-tbody').children(0).click()
    })
})
