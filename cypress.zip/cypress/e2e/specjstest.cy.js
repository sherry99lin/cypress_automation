describe('empty spec', () => {
  it('passes', () => {
    cy.visit('https://staging.omnicloud.tech/')
  })
  it('first test', () =>{

    cy.contains('登 入').click()
    cy.get('[name="username"]').should('contain','').clear().type('admin@RUBYS')
    cy.get('[name="password"]').should('contain','').clear().type('YvrK3ZQX')
    cy.get('[name="username"]')
      .parents('form')
      .contains('[type="submit"]','登入')
      .click()
    cy.get('[i18nkey="workflow"]').click()
    cy.wait(3000)
    // cy.get('.ant-btn ant-btn-default action-btn')
        // .parents('td').find('button').should('contain','編輯').click()
    cy.get('[data-row-key="4454"]')
    // cy.get('.ant-table-tbody').children()
})
})